document.addEventListener("DOMContentLoaded", () => {
  const form = document.querySelector("form");
  if (!form) return;

  // Adiciona classe ao form para estilização
  form.classList.add("search-container");

  // Adiciona classes aos inputs e botão
  form.querySelectorAll("input").forEach(input => input.classList.add("search-input"));
  const button = form.querySelector("button");
  if (button) button.classList.add("search-button");
});
