document.addEventListener("DOMContentLoaded", () => {
  const resultsContainer = document.querySelector(".resultados");
  if (!resultsContainer) return;

  // Pega a cidade pesquisada (supondo que esteja no input do form)
  const cidadeInput = document.querySelector("input[name='cidade']");
  if (!cidadeInput) return;
  const cidade = cidadeInput.value.toLowerCase();

  // Pega todos os links atuais
  const existingLinks = Array.from(resultsContainer.querySelectorAll("a")).map(a => a.href);

  // Lista de links extras simulados ou obtidos via pesquisa adicional
  const extraLinks = [
    `https://www.instagram.com/${cidade}_oficial/`,
    `https://www.instagram.com/${cidade}_frevo/`,
    `https://www.instagram.com/${cidade}_eventos/`,
    `https://www.instagram.com/${cidade}_dance/`,
    `https://www.instagram.com/${cidade}_cultura/`
  ];

  // Filtra para não repetir links já existentes
  const newLinks = extraLinks.filter(link => !existingLinks.includes(link));

  // Cria cards adicionais
  newLinks.forEach((link, index) => {
    const card = document.createElement("div");
    card.className = "autonomy-card"; // mantém compatibilidade com corrector-lab

    const a = document.createElement("a");
    a.href = link;
    a.textContent = link;
    a.target = "_blank";

    card.appendChild(a);
    resultsContainer.appendChild(card);
  });
});
