document.addEventListener("DOMContentLoaded", () => {
  const body = document.querySelector("body");
  if (!body) return;

  // Container do console
  const consoleContainer = document.createElement("div");
  consoleContainer.className = "afterbox-console";

  const consoleTitle = document.createElement("h2");
  consoleTitle.textContent = "🟢 Console do QQfrevo Progressive Autonomy";
  consoleContainer.appendChild(consoleTitle);

  const consoleOutput = document.createElement("div");
  consoleOutput.className = "afterbox-console-output";

  // Exemplo de logs (pode ser substituído dinamicamente)
  const logs = [
    "Servidor rodando em http://localhost:3000",
    "Mods ativos: search-bar, quadros-layout, corrector-lab",
    "Nenhum erro detectado",
    "Busca inicial carregada com sucesso"
  ];

  logs.forEach(log => {
    const p = document.createElement("p");
    p.textContent = log;
    consoleOutput.appendChild(p);
  });

  consoleContainer.appendChild(consoleOutput);

  // -------------------------
  // Estilo neon verde
  // -------------------------
  const style = document.createElement("style");
  style.textContent = `
    .afterbox-console { 
      margin: 20px 0; 
      padding: 15px; 
      border: 2px solid #00ff00; 
      background: #121212; 
      color: #00ff00; 
      border-radius: 8px;
      font-family: monospace;
    }
    .afterbox-console h2 { color: #00ff00; margin-bottom: 10px; }
    .afterbox-console-output p { color: #00ff00; margin: 2px 0; }
  `;
  document.head.appendChild(style);

  // Adiciona no final da página
  body.appendChild(consoleContainer);
});
