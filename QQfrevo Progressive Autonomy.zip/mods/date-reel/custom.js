document.addEventListener("DOMContentLoaded", () => {
  const resultsContainer = document.querySelector(".resultados");
  if (!resultsContainer) return;

  // Filtra apenas perfis válidos (ignorando páginas indisponíveis)
 const profileCards = Array.from(resultsContainer.querySelectorAll("a")).filter(a => {
  const parentText = a.parentElement?.textContent || "";
  // Ignora perfis que contém o aviso de página indisponível
  return !parentText.includes("Esta página não está disponível");
});


  if (profileCards.length === 0) return;

  const profileLinks = profileCards.map(a => a.href);

  // Cria container date-reel
  const mainContainer = document.createElement("div");
  mainContainer.className = "date-reel-container";

  // Parte superior: pesquisa
  const searchPart = document.createElement("div");
  searchPart.className = "date-reel-search";
  searchPart.appendChild(resultsContainer);
  mainContainer.appendChild(searchPart);

  // Parte inferior: últimos posts (foto ou Reel)
  const postsPart = document.createElement("div");
  postsPart.className = "date-reel-reels";

  const postsTitle = document.createElement("h3");
  postsTitle.textContent = "🎬 Último post dos perfis";
  postsPart.appendChild(postsTitle);

  profileLinks.forEach((profileUrl, index) => {
    const postCard = document.createElement("div");
    postCard.className = "reel-card";

    // Foto do último post (placeholder)
    const img = document.createElement("img");
    img.src = `https://via.placeholder.com/150/00ffb3/000000?text=Post+${index+1}`;
    img.alt = `Último post do perfil ${index+1}`;

    // Nome do perfil
    const profileName = document.createElement("div");
    profileName.textContent = profileUrl.split("/").filter(Boolean).pop();

    // Data do último post (placeholder)
    const date = document.createElement("div");
    date.className = "reel-date";
    const postDate = new Date();
    postDate.setDate(postDate.getDate() - (index + 1));
    date.textContent = `Postado: ${postDate.toLocaleDateString()}`;

    postCard.appendChild(img);
    postCard.appendChild(profileName);
    postCard.appendChild(date);

    postsPart.appendChild(postCard);
  });

  mainContainer.appendChild(postsPart);

  // Adiciona ao body
  document.body.appendChild(mainContainer);
});
