const cards = document.querySelectorAll(".card, .autonomy-card");

cards.forEach(async (card) => {
  const linkEl = card.querySelector(".info a");
  if (!linkEl) return;

  const url = linkEl.href;

  try {
    const res = await fetch(url);
    const text = await res.text();

    if (text.includes("Esta página não está disponível")) {
      card.remove(); // perfil inexistente
    }
  } catch (err) {
    console.log("Erro ao verificar perfil:", url);
    card.remove(); // remove por precaução
  }
});
