// server.js
// instalar dependências: npm install express axios cheerio sqlite3

const express = require("express");
const axios = require("axios");
const cheerio = require("cheerio");
const sqlite3 = require("sqlite3").verbose();
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = 3000;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Servir arquivos estáticos
app.use("/public", express.static(path.join(__dirname, "public")));
app.use("/mods", express.static(path.join(__dirname, "mods")));

// Banco de dados SQLite
const db = new sqlite3.Database("favoritos.db");
db.run("CREATE TABLE IF NOT EXISTS favoritos (id INTEGER PRIMARY KEY AUTOINCREMENT, link TEXT)");

// Ler config.json
let config = { activeMods: [] };
try {
  const raw = fs.readFileSync("config.json", "utf8");
  const parsed = JSON.parse(raw);
  if (Array.isArray(parsed.activeMods)) {
    config.activeMods = parsed.activeMods.filter(m => typeof m === "string" && m.trim() !== "");
  }
} catch (err) {
  console.error("⚠️ Erro ao ler config.json:", err);
}

// Função para gerar o <head>
function gerarHead(titulo = "qqfrevo Progressive Autonomy") {
  let publicCSS = "";
  let modCSS = "";
  let modJS = "";

  // Public CSS
  const publicPath = path.join(__dirname, "public", "css");
  if (fs.existsSync(publicPath)) {
    publicCSS = fs.readdirSync(publicPath)
      .filter(f => f.endsWith(".css"))
      .map(f => `<link rel="stylesheet" href="/public/css/${f}">`)
      .join("\n");
  }

  // Mods ativos
  config.activeMods.forEach(modName => {
    const modDir = path.join(__dirname, "mods", modName);
    if (!fs.existsSync(modDir)) return;
    const files = fs.readdirSync(modDir);
    modCSS += files
      .filter(f => f.endsWith(".css"))
      .map(f => `<link rel="stylesheet" href="/mods/${modName}/${f}">`)
      .join("\n");
    modJS += files
      .filter(f => f.endsWith(".js"))
      .map(f => `<script src="/mods/${modName}/${f}"></script>`)
      .join("\n");
  });

  return `
  <head>
    <meta charset="UTF-8">
    <title>${titulo}</title>
    ${publicCSS}
    ${modCSS}
  </head>
  ${modJS}`;
}

// Página inicial
app.get("/", (req, res) => {
  const head = gerarHead();
  const html = `
  <!DOCTYPE html>
  <html lang="pt-BR">
  ${head}
  <body>
    <header><h2>qqfrevo Progressive Autonomy</h2></header>
    <form method="POST" action="/buscar" id="searchForm">
      <input type="text" name="cidade" placeholder="Cidade" required>
      <input type="text" name="tipo" placeholder="Tipo de Frevo" required>
      <button type="submit">Buscar</button>
    </form>

    <div id="loading" style="display:none;text-align:center;margin-top:20px;">
      <p>🔎 Buscando resultados... aguarde...</p>
    </div>

    <script>
      document.getElementById("searchForm").addEventListener("submit", () => {
        document.getElementById("loading").style.display = "block";
      });
    </script>

    <p><a href="/favoritos">⭐ Ver Favoritos</a></p>
  </body>
  </html>`;
  res.send(html);
});

// Rota /buscar (atualizada com múltiplas páginas)
app.post("/buscar", async (req, res) => {
  const { cidade, tipo } = req.body || {};
  if (!cidade || !tipo) return res.send("Dados do formulário ausentes.");

  const query = `instagram ${tipo} ${cidade}`;
  const maxPages = 3; // 🔹 número de páginas (8 resultados por página)

  const links = new Set();

  try {
    for (let i = 0; i < maxPages; i++) {
      const searchUrl = `https://duckduckgo.com/html/?q=${encodeURIComponent(query)}&s=${i * 20}`;
      const { data } = await axios.get(searchUrl, { headers: { "User-Agent": "Mozilla/5.0" } });
      const $ = cheerio.load(data);

      $("a").each((_, el) => {
        const href = $(el).attr("href");
        if (!href) return;
        const match = href.match(/uddg=([^&]+)/);
        const decoded = match ? decodeURIComponent(match[1]) : href;
        if (/^https?:\/\/(www\.)?instagram\.com\/[a-zA-Z0-9._]+\/?$/.test(decoded))
          links.add(decoded);
      });
    }

    const head = gerarHead(`Resultados — qqfrevo Progressive Autonomy`);
    let html = `
    <!DOCTYPE html>
    <html lang="pt-BR">
    ${head}
    <body>
      <header><h2>qqfrevo Progressive Autonomy</h2></header>
      <div class="resultados">`;

    if (links.size > 0) {
      for (const link of links) {
        let profilePic = "https://via.placeholder.com/100/00ff00/000000?text=IG";
        try {
          const { data: profileHTML } = await axios.get(link, { headers: { "User-Agent": "Mozilla/5.0" } });
          const $profile = cheerio.load(profileHTML);
          const pic = $profile('meta[property="og:image"]').attr('content');
          if (pic) profilePic = pic;
        } catch (err) {
          console.log(`Erro ao buscar foto do perfil ${link}:`, err.message);
        }

        html += `<div class="card">
          <div class="fotos">
            <img src="${profilePic}" alt="Foto do perfil">
          </div>
          <div class="info">
            <a href="${link}" target="_blank">${link}</a>
            <form method="POST" action="/favoritar">
              <input type="hidden" name="link" value="${link}">
              <button type="submit">⭐</button>
            </form>
          </div>
        </div>`;
      }
    } else {
      html += `<p>Nenhum resultado encontrado.</p>`;
    }

    html += `</div><p><a href="/">🔙 Voltar</a></p></body></html>`;
    res.send(html);

  } catch (err) {
    res.send("Erro ao buscar: " + err.message);
  }
});

// Favoritar
app.post("/favoritar", (req, res) => {
  const { link } = req.body;
  if (!link) return res.send("Link inválido.");
  db.run("INSERT INTO favoritos (link) VALUES (?)", [link], (err) => {
    if (err) return res.send("Erro ao salvar favorito.");
    res.redirect("/favoritos");
  });
});

// Favoritos
app.get("/favoritos", (req, res) => {
  db.all("SELECT * FROM favoritos", [], (err, rows) => {
    if (err) return res.send("Erro ao carregar favoritos.");
    const head = gerarHead("Favoritos — qqfrevo Progressive Autonomy");
    let html = `
    <!DOCTYPE html>
    <html lang="pt-BR">
    ${head}
    <body>
      <header><h2>⭐ Favoritos</h2></header>
      <div class="favoritos">`;
    rows.forEach(row => {
      html += `<div class="fav-item"><a href="${row.link}" target="_blank">${row.link}</a></div>`;
    });
    html += `<p><a href="/">🔙 Voltar</a></p></div></body></html>`;
    res.send(html);
  });
});

// Iniciar servidor
app.listen(PORT, () => {
  console.log(`🚀 qqfrevo Progressive Autonomy rodando em http://localhost:${PORT}`);
});
