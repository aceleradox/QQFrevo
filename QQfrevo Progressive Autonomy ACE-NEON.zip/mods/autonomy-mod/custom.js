/**
 * Autonomy Mod
 * Exibe até 3 fotos iniciais de cada perfil no /buscar
 * Compatível com corrector-lab
 */

document.addEventListener("DOMContentLoaded", () => {
  const resultsContainer = document.querySelector(".resultados");
  if (!resultsContainer) return;

  const cards = resultsContainer.querySelectorAll(".card");

  cards.forEach(card => {
    const fotosDiv = card.querySelector(".fotos");
    if (!fotosDiv) return;

    // Se já houver apenas uma foto, duplicamos para ter 3 placeholders
    const existingImg = fotosDiv.querySelector("img");
    if (!existingImg) return;

    fotosDiv.innerHTML = ""; // limpa
    for (let i = 0; i < 3; i++) {
      const img = document.createElement("img");
      img.src = existingImg.src; // mesma foto do perfil
      img.alt = `Foto ${i + 1}`;
      img.classList.add("autonomy-photo");
      fotosDiv.appendChild(img);
    }
  });
});
