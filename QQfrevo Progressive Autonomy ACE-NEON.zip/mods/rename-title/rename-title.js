/**
 * Rename-Title Mod
 * Altera o nome padrão do app "qqfrevo Progressive Autonomy"
 * sem modificar o server.js original.
 */

document.addEventListener("DOMContentLoaded", () => {
  const novoNome = "QQFrevo AcE /-/ NeoN Search"; // 🔹 altere aqui o nome desejado

  // Altera o título da aba
  document.title = novoNome;

  // Altera o texto do cabeçalho
  const header = document.querySelector("header h2");
  if (header) header.textContent = novoNome;

  // Adiciona uma leve animação neon
  if (header) {
    header.style.textShadow = "0 0 10px #00f6ff, 0 0 20px #00f6ff, 0 0 30px #00f6ff";
    header.style.transition = "0.3s";
  }
});
