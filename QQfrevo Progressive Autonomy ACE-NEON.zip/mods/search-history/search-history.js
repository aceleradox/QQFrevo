/**
 * Search-History Mod
 * Exibe histórico de pesquisas recentes na página principal.
 * Armazena os termos no localStorage.
 */

document.addEventListener("DOMContentLoaded", () => {
  const form = document.querySelector("form[action='/buscar']");
  const historyContainer = document.createElement("div");
  historyContainer.className = "search-history";

  // Adiciona o container abaixo do formulário
  if (form && form.parentNode) {
    form.insertAdjacentElement("afterend", historyContainer);
  }

  // Carregar histórico salvo
  const loadHistory = () => {
    const history = JSON.parse(localStorage.getItem("qqfrevo_history") || "[]");
    renderHistory(history);
  };

  // Renderizar lista de histórico
  const renderHistory = (list) => {
    if (list.length === 0) {
      historyContainer.innerHTML = `<p class="no-history">🔍 Nenhuma busca recente</p>`;
      return;
    }

    historyContainer.innerHTML = `
      <h3>Pesquisas Recentes</h3>
      <ul>
        ${list
          .map(
            (item) => `
          <li class="history-item" data-cidade="${item.cidade}" data-tipo="${item.tipo}">
            <span>📍 ${item.cidade} — 🎵 ${item.tipo}</span>
            <button class="rebuscar">Rebuscar</button>
          </li>
        `
          )
          .join("")}
      </ul>
      <button class="limpar-historico">🧹 Limpar Histórico</button>
    `;

    // Rebuscar ao clicar
    document.querySelectorAll(".rebuscar").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        const li = e.target.closest("li");
        if (!li) return;
        const cidade = li.dataset.cidade;
        const tipo = li.dataset.tipo;

        // Preenche os campos e envia o formulário automaticamente
        form.querySelector("input[name='cidade']").value = cidade;
        form.querySelector("input[name='tipo']").value = tipo;
        form.submit();
      });
    });

    // Limpar histórico
    const clearBtn = document.querySelector(".limpar-historico");
    if (clearBtn) {
      clearBtn.addEventListener("click", () => {
        localStorage.removeItem("qqfrevo_history");
        loadHistory();
      });
    }
  };

  // Salvar busca ao enviar o formulário
  if (form) {
    form.addEventListener("submit", () => {
      const cidade = form.querySelector("input[name='cidade']").value.trim();
      const tipo = form.querySelector("input[name='tipo']").value.trim();
      if (!cidade || !tipo) return;

      let history = JSON.parse(localStorage.getItem("qqfrevo_history") || "[]");

      // Evita duplicar
      history = history.filter(
        (h) => !(h.cidade === cidade && h.tipo === tipo)
      );

      // Adiciona no topo
      history.unshift({ cidade, tipo });

      // Limite de 8 itens
      history = history.slice(0, 8);

      localStorage.setItem("qqfrevo_history", JSON.stringify(history));
    });
  }

  loadHistory();
});
