document.addEventListener("DOMContentLoaded", () => {
  const table = document.querySelector("table");
  if (!table) return;

  const rows = table.querySelectorAll("tbody tr");
  const grid = document.createElement("div");
  grid.className = "result-grid";

  rows.forEach(row => {
    const img = row.querySelector("img")?.src || "";
    const link = row.querySelector("a")?.href || "#";
    const text = row.querySelector("a")?.innerText || "(sem título)";
    const form = row.querySelector("form");

    const card = document.createElement("div");
    card.className = "result-card";
    card.innerHTML = `
      <img src="${img}" alt="preview">
      <a href="${link}" target="_blank">${text}</a>
    `;
    if (form) card.appendChild(form.cloneNode(true));
    grid.appendChild(card);
  });

  table.replaceWith(grid);
});
