/**
 * Afterbox Mod — Atualizado
 * Adiciona informações do sistema + gerador de mensagens motivacionais
 * com visual neon e interação simples.
 */

document.addEventListener("DOMContentLoaded", () => {
  const container = document.createElement("div");
  container.className = "afterbox-console";

  // Lista de mensagens motivacionais
  const mensagens = [
    "🔥 Acredite: o progresso começa com um passo de coragem!",
    "🌟 Continue — cada erro é um passo em direção ao acerto!",
    "🚀 Seu foco cria sua realidade. Continue avançando!",
    "🎯 A constância vence o talento quando o talento não é constante!",
    "💪 Tudo começa com a decisão de tentar!",
    "⚡ A energia que você emite atrai o que você merece!",
    "🌌 O impossível é só o possível que ainda não foi tentado!",
    "🌀 Se mova. Mesmo devagar, ainda é progresso!"
  ];

  // Função para escolher uma aleatória
  const gerarMensagem = () => mensagens[Math.floor(Math.random() * mensagens.length)];

  // Cria a estrutura HTML do painel
  container.innerHTML = `
    <h3>🧠 Painel Afterbox</h3>
    <div class="info">
      <p><strong>Status:</strong> App rodando com Node.js</p>
      <p><strong>Mods ativos:</strong> ${(window.activeMods || []).join(", ") || "Desconhecidos"}</p>
      <p><strong>Data/Hora:</strong> ${new Date().toLocaleString("pt-BR")}</p>
    </div>
    <div class="motivacional">
      <p id="mensagem">${gerarMensagem()}</p>
      <button id="novaMensagem">Nova mensagem 🔁</button>
    </div>
  `;

  document.body.appendChild(container);

  // Atualiza mensagem ao clicar
  document.getElementById("novaMensagem").addEventListener("click", () => {
    document.getElementById("mensagem").textContent = gerarMensagem();
  });
});
