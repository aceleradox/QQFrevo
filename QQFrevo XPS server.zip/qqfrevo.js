// instalar: npm install express body-parser axios cheerio sqlite3

const express = require("express");
const bodyParser = require("body-parser");
const axios = require("axios");
const cheerio = require("cheerio");
const sqlite3 = require("sqlite3").verbose();
const path = require("path");

const app = express();
const PORT = 3000;

// Configurar body-parser
app.use(bodyParser.urlencoded({ extended: true }));

// Banco de dados SQLite
const db = new sqlite3.Database("favoritos.db");
db.run("CREATE TABLE IF NOT EXISTS favoritos (id INTEGER PRIMARY KEY AUTOINCREMENT, link TEXT)");

// Rota principal (formulário HTML)
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "views", "index.html"));
});

// Rota para pesquisa
app.post("/buscar", async (req, res) => {
  const { cidade, tipo } = req.body;
  const query = `instagram ${tipo} ${cidade}`;
  const url = `https://duckduckgo.com/html/?q=${encodeURIComponent(query)}`;

  try {
    const { data } = await axios.get(url, {
      headers: { "User-Agent": "Mozilla/5.0" }
    });

    const $ = cheerio.load(data);
    const links = new Set();

    $("a").each((_, el) => {
      const href = $(el).attr("href");
      if (!href) return;
      const match = href.match(/uddg=([^&]+)/);
      if (match) {
        const instaLink = decodeURIComponent(match[1]);
        if (instaLink.includes("instagram.com")) links.add(instaLink);
      } else if (href.includes("instagram.com")) {
        links.add(href);
      }
    });

    // HTML completo com tabela e CSS dark
    let html = `
    <!DOCTYPE html>
    <html lang="pt-BR">
    <head>
      <meta charset="UTF-8">
      <title>Resultados - ${tipo} em ${cidade}</title>
      <style>
        body { font-family: Arial; background: #121212; color: #00f0ff; padding: 20px; }
        h2 { color: #00f0ff; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #00f0ff; padding: 10px; text-align: left; }
        th { background: #1a1a1a; color: #00f0ff; }
        tr:nth-child(even) { background: #1e1e1e; }
        tr:hover { background: #272727; transform: scale(1.01); transition: transform 0.2s; }
        button { padding: 5px 10px; border-radius: 5px; border: none; background: #00f0ff; color: #121212; cursor: pointer; }
        button:hover { background: #00c0ff; }
        a { color: #00f0ff; text-decoration: none; }
        a:hover { text-decoration: underline; }
        img { width: 50px; height: 50px; border-radius: 50%; object-fit: cover; }
      </style>
    </head>
    <body>
      <h2>Resultados para "${tipo}" em "${cidade}"</h2>
    `;

    if (links.size > 0) {
      html += `<table>
        <thead>
          <tr>
            <th>Foto</th>
            <th>Link</th>
            <th>Favoritar</th>
          </tr>
        </thead>
        <tbody>`;
      
      links.forEach(link => {
        html += `
          <tr>
            <td><img src="https://via.placeholder.com/50?text=IG"></td>
            <td><a href="${link}" target="_blank">${link}</a></td>
            <td>
              <form method="POST" action="/favoritar">
                <input type="hidden" name="link" value="${link}">
                <button type="submit">⭐</button>
              </form>
            </td>
          </tr>
        `;
      });

      html += `</tbody></table>`;
    } else {
      html += "<p>⚠️ Nenhum perfil do Instagram encontrado.</p>";
    }

    html += `<p><a href='/'>🔙 Voltar</a></p></body></html>`;

    res.send(html);

  } catch (err) {
    res.send("Erro: " + err.message);
  }
});

// Rota para favoritar link
app.post("/favoritar", (req, res) => {
  const { link } = req.body;
  db.run("INSERT INTO favoritos (link) VALUES (?)", [link], (err) => {
    if (err) {
      return res.send("Erro ao salvar nos favoritos.");
    }
    res.send(`<p>✅ Adicionado aos favoritos!</p><p><a href="/favoritos">Ver favoritos</a></p><p><a href="/">Voltar</a></p>`);
  });
});

// Rota para listar favoritos
app.get("/favoritos", (req, res) => {
  db.all("SELECT * FROM favoritos", [], (err, rows) => {
    if (err) {
      return res.send("Erro ao carregar favoritos.");
    }
    let html = `
      <!DOCTYPE html>
      <html lang="pt-BR">
      <head>
        <meta charset="UTF-8">
        <title>Favoritos</title>
        <style>
          body { font-family: Arial; background: #121212; color: #00f0ff; padding: 20px; }
          h2 { color: #00f0ff; }
          a { color: #00f0ff; text-decoration: none; }
          a:hover { text-decoration: underline; }
        </style>
      </head>
      <body>
        <h2>⭐ Favoritos</h2>
    `;
    rows.forEach(row => {
      html += `<p><a href="${row.link}" target="_blank">${row.link}</a></p>`;
    });
    html += `<p><a href="/">🔙 Voltar</a></p></body></html>`;
    res.send(html);
  });
});

// Iniciar servidor
app.listen(PORT, () => {
  console.log(`🚀 o QQfrevo XPS server esta rodando nessa URL: http://localhost:${PORT}`);
});
