// instalar: npm install axios cheerio readline-sync
const axios = require("axios");
const cheerio = require("cheerio");
const readline = require("readline-sync");

async function buscarEventos() {
  const cidade = readline.question("Cidade: ");
  const tipo = readline.question("Tipo de evento (baile funk, desande, som automotivo...): ");

  const query = `instagram ${tipo} ${cidade}`;
  const url = `https://duckduckgo.com/html/?q=${encodeURIComponent(query)}`;

  try {
    const { data } = await axios.get(url, {
      headers: { "User-Agent": "Mozilla/5.0" }
    });

    const $ = cheerio.load(data);
    const links = new Set();

    $("a").each((_, el) => {
      const href = $(el).attr("href");
      if (!href) return;

      // pega apenas o link real do Instagram se houver 'uddg='
      const match = href.match(/uddg=([^&]+)/);
      if (match) {
        const instaLink = decodeURIComponent(match[1]);
        if (instaLink.includes("instagram.com")) {
          links.add(instaLink);
        }
      } else if (href.includes("instagram.com")) {
        // caso seja link direto
        links.add(href);
      }
    });

    if (links.size > 0) {
      console.log(`\n🔎 Perfis/páginas do Instagram para "${tipo}" em "${cidade}":\n`);
      [...links].forEach(l => console.log(l));
    } else {
      console.log("⚠️ Nenhum perfil do Instagram encontrado.");
    }

  } catch (err) {
    console.error("Erro:", err.message);
  }
}

buscarEventos();
